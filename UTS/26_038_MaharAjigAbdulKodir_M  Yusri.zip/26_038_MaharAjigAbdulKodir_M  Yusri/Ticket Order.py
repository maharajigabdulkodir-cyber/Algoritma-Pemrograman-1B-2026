Reguler = 40000
VIP = 75000
VVIP = 100000

while true:
    input(int)("masukan nominal tiket:)")
    if == 40000
        reguler= 40000:
    elif tiket == 75000:
    else:
        print("Nominal salah")

        



        
    
    
        
        
    
        